function funcion_representa_hiperplano_separacion_2_3_Dim(coef_d12,X)

 A = coef_d12(1);
     B = coef_d12(2);
     C = coef_d12(3);
    
if(size(coef_d12,2)==3)
    
    
    Yprediccion = A*X(:,1)+B*X(:,2)+C;
    Xfrontera = X(Yprediccion==0,:);
     hold on;
    plot(Xfrontera(:,1),Xfrontera(:,2),'.black');
    grid on;

end

if(size(coef_d12,2) == 4) 
    D = coef_d12(4);
    
    Yprediccion = A*X(:,1)+B*X(:,2)+C*X(:,3)+D;
    
     Xfrontera = X(Yprediccion==0,:);
    x1min = min(X(:,1));
    x1max = max(X(:,1));

    x2min = min(X(:,2));
    x2max = max(X(:,2));

    [x1Plano, x2Plano] = meshgrid(x1min:0.01:x1max,x2min:0.01:x2max);
    x3Plano = -(A*x1Plano + B*x2Plano + D)/ (C+eps);
    plot3(Xfrontera(:,1),Xfrontera(:,2),Xfrontera(:,3),'.black');
    surf(x1Plano,x2Plano, x3Plano)
    grid on;
end

end

